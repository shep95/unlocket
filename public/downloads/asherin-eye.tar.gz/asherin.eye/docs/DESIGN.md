# ADAM design system

The console is an instrument. The globe and its live data are the subject;
the chrome around them should be legible, quiet and consistent, and should
only draw the eye when something has changed state.

## Where things live

| File | What it owns |
| --- | --- |
| `src/ui/styles/fonts.css` | IBM Plex Sans (variable: width 85–100 %, weight 300–700) and IBM Plex Mono, served from `public/fonts` (SIL OFL 1.1) |
| `src/ui/styles/tokens.css` | Every colour, type size, radius, spacing step and motion value, plus the legacy variable names that older sheets read |
| `src/ui/styles/console.css` | The primary chrome: identity, globe toolbar, ops rail, corner readouts, flyouts, key chip |
| `src/ui/adam/motion.css` | State-change motion (layer online, acquisition, confirm, ignition) |
| `src/ui/styles/cyber.css` | The opt-in cyber layout, which keeps its own red/slate palette |
| `tools/design/normalize-colors.mjs` | Idempotent migration that folds stray literals onto the palette and strips coloured glows. `--write` to apply |

Change a colour in `tokens.css`, not in a component sheet.

## Colour

Neutrals are a cold graphite (OKLCH hue 240, chroma ≤ 0.01): `--n-0`
(background) to `--n-4` (strong fill), text `--fg-1` to `--fg-4`, and three
hairline strengths `--line-1..3`. Secondary text is 7.9:1 on a panel and
tertiary 4.9:1.

Colour is semantic, after avionics display practice (FAA AC 25-11B):

| Token | Meaning |
| --- | --- |
| `--signal` (cyan) | selected, operator-set, interactive focus |
| `--live` (green) | a feed is live, a thing is engaged |
| `--caution` (amber) | stale, partial, degraded, elevated |
| `--warning` (red) | failed, tripped — rare so it carries weight |

A control at rest is neutral. Signal colour appears only when the control is
pressed, selected or focused. Data layers on the globe keep their own colours.

## Surfaces

Panels are near-opaque (`--surface-panel`, 94 %; 97 % over photographic
basemaps) with a 1px edge and a dark drop shadow. There is no backdrop blur
(`--surface-blur: none`): a blur over a live WebGL globe is recomputed on
every frame. No surface gradients, no glows.

## Type

- Interface text: IBM Plex Sans. Rail and dense labels use the narrow width
  (`font-stretch: 88 %`).
- Numbers that must line up: IBM Plex Mono, or tabular figures (on by
  default for the whole body).
- Scale: 10 / 11 / 12 / 13 / 15 / 18 / 24 px (`--text-2xs` … `--text-2xl`).
- Lettering: the house style sets **labels** (buttons, tabs, headings,
  `*-label`, `*-title`) in lowercase. **Data keeps its case** — callsigns,
  ICAO/MMSI codes, MGRS, URLs, values, readouts and Shepherd's replies.
  Settings → lettering turns the house style off.

## Geometry

`--radius-1` 2px for controls and chips, `--radius-2` 3px for panels,
`50 %` only for true circles. No pills.

## Motion

Things arrive decelerating (`--ease-out`) and leave accelerating
(`--ease-in`); durations are `--dur-1..4` (100–400 ms). Motion marks a change
of state and stops: nothing spins, pulses forever, glows or flickers.
Attention pulses run three cycles and then hold. `prefers-reduced-motion`
reduces every animation and transition to a single frame.

## The ops rail

Panels dock their chip with `dockRailChip(doc, chip, { group, order })`
from `src/ui/adam/railDock.js`. Groups are `analyze`, `world`, `session`
and `agent`; chips sort by `order` inside a group, so the rail reads the
same on every load and in every language. A chip installed before the rail
exists docks when the rail appears (a MutationObserver, not polling).
