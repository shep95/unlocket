# Third-party software notices

The project depends on third-party npm packages whose own licenses apply. This
file records the packages added for the browser-local SDR feature; the complete
resolved dependency inventory remains in `package-lock.json`.

## Web RTL-SDR

- Package: `@jtarrio/webrtlsdr` 3.0.6
- Author: Jacobo Tarrio Barreiro; portions copyright Google Inc.
- Source: <https://github.com/jtarrio/webrtlsdr>
- License: Apache License 2.0
- License text: <https://www.apache.org/licenses/LICENSE-2.0>

## Signals

- Package: `@jtarrio/signals` 0.10.1
- Author: Jacobo Tarrio Barreiro
- Source: <https://github.com/jtarrio/signals>
- License: Apache License 2.0
- License text: <https://www.apache.org/licenses/LICENSE-2.0>

## IBM Plex (fonts)

- Files: `public/fonts/plex-sans-*.woff2`, `public/fonts/plex-mono-*.woff2`
- Author: IBM Corp. (Reserved Font Name "Plex")
- Source: <https://github.com/IBM/plex>, subset as served by Google Fonts
- License: SIL Open Font License 1.1 — full text in `public/fonts/OFL.txt`
